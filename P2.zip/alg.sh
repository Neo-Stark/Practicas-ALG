#!/bin/bash
rm *.dat

for ((N=10;N<=8500;N=N+50))
do
  ./repDyV $N >> salidaDyV.dat
  ./repCuad $N >> salidaCuad.dat
done